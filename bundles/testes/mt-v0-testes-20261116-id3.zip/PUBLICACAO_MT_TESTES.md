# Lexblum — deploy do MT/V0 em ambiente de TESTES

Esta é uma **preparação de arquivos**, não uma publicação. Conteúdo técnico, não canônico. A ordem autoral de 16/11/2026 ID3 é publicar os MT no centro de distribuição para executar o teste de transporte HTTPS remoto. Repositório de código do APP fica privado; não alterar PRINCIPAL/SOSL nem gerar APK neste passo.

## Artefatos para GitHub Release

A pasta `release-assets` tem exatamente os nomes exigidos pelo Worker atual: `oga-catalog.envelope`, `sdc-catalog.envelope` e oito objetos com nome SHA-256. NÃO renomear arquivos nem recalcular envelopes assinados. O catálogo de recursos gráficos `catalog.envelope` NÃO está neste lote e não deve ser falsificado; o escopo é MT Oga + MT SDC. O pin correto é `audit/public.key` / `audit/manifest.json`.

## Ações necessárias em executor com GitHub Release e conta Cloudflare autorizados

1. Confirmar HEAD, licença e ausência de alterações concorrentes. Auditar que `LIGORVERSO/lexblum-approved-assets` continua separado do repositório privado de código e que o Worker existente corresponde a `lexblum-content.ligorverso.workers.dev`. Verificar se já há uma tag aprovada ativa; não sobrescrevê-la.
2. Reexecutar as verificações assinadas dos dois envelopes + objetos, confrontando `audit/manifest.json`, SHA e pin. Revisar especificamente ausência de dados pessoais/segredos e classificação técnica; a publicação do release torna esses arquivos PUBLICAMENTE acessíveis, mesmo se o APK não for distribuído.
3. Criar `mt-v0-testes-20261116-id3` como GitHub **draft prerelease**, anexando TODOS os dez arquivos da pasta `release-assets` ao mesmo release em `LIGORVERSO/lexblum-approved-assets`. Pela CLI autenticada existente, por exemplo, executar na pasta raiz do pacote: `gh release create mt-v0-testes-20261116-id3 release-assets/* --draft --prerelease --latest=false --target main --title 'MT/V0 técnico de TESTES — não canônico' --notes 'Fixture técnica para transporte HTTPS Oga_PL + Lexblum_SDC; não é conteúdo autoral homologado.' -R LIGORVERSO/lexblum-approved-assets`. Não solicitar token no chat.
4. Ler independentemente os assets e respectivos tamanhos/digests do draft; diante de divergência, não publicar. Confirmados todos, tornar o **prerelease** visível usando autorização ID3 para este par específico; não promover como release final, nem marcar como latest.
5. Ajustar somente a configuração necessária do Worker EXISTENTE para owner=`LIGORVERSO`, repository=`lexblum-approved-assets` e tag=`mt-v0-testes-20261116-id3` (após inspeção do estado anterior); não implantar Worker paralelo nem substituir release de produção já ativa.
6. Executar GET e HEAD de `/oga/catalog.envelope`, `/sdc/catalog.envelope` e objetos; conferir 200/206, Range, ETag, If-Range, SHA-256, assinaturas, rejeição de corrupção e downloads intermitentes. Se o Worker retornar 403 ou outro erro, determinar a causa antes de contornar ACL. Provar instalação/rollback em ambiente isolado pelo consumidor Android/Java. Ausência de `catalog.envelope` para recursos gráficos pode produzir 404 nesse canal; registrar separadamente.
7. Só depois marcar o gate remoto de MT como satisfeito. A geração e instalação de APK permanecem gates separados que exigem autorização específica. Registrar readback no Plano/Registro/Issue #9 e TypeDB, com links e SHA, sem declarar visual/autorais aceitos.

**Limitação do chat comum em 16/11:** o conector GitHub não disponibiliza criação/upload de Release, não há conector Cloudflare autenticado, e o Device Bridge está offline. Portanto, criação do draft, exposição e binding do Worker NÃO foram efetuados neste pacote.
