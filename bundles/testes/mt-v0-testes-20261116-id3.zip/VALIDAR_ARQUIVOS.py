from pathlib import Path
from hashlib import sha256
import json
r=Path(__file__).resolve().parent; m=json.loads((r/'audit/manifest.json').read_text())
for name,expected in m['files'].items():
 b=(r/'release-assets'/name).read_bytes()
 assert len(b)==expected['size'] and sha256(b).hexdigest()==expected['sha256'],name
for name in ('oga-catalog.envelope','sdc-catalog.envelope'):
 c=json.loads((r/'release-assets'/name).read_bytes())
 assert c['payload']['channel']=='TESTES'
 for ob in c['payload']['objects']:
  p=r/'release-assets'/ob['sha256'];assert p.is_file() and p.stat().st_size==ob['bytes'],ob['id']
print('MT_V0_RELEASE_ASSETS_INTEGRITY_PASS:',len(m['files']),'assets')
